%%=========================================================================
% Stvaranje FIS strukture
%
% Na vjezbi je FIS struktura stvorena uz puno koristenja FIS editora, sto
% nije moguce reproducirati u ovoj skripti. Zbog toga cemo FIS strukturu
% ucitati iz datoteke, uz navodjenje nekih kljucnih naredbi u komentarima

fuzzyPI = readfis('fuzzyPI.fis');

%--- Racunanje koeficijenata singletona za emulaciju PI kontrolera ---
c_e = [-4,-3,-2,-1,0,1,2,3,4];   % Centroidi pogreske
rule_idx1=[1:9]; 
A = -c_e.^3+3*c_e.^2-4*c_e;    % Vrijednosti izlaznih singletona

% Pridjeli vrijednosti izlaznim singletonima
fuzzyPI.output.range = [min(A) max(A)];
for i = 1:length(fuzzyPI.output.mf)
    fuzzyPI.output.mf(i).name = ['A' mat2str(i)];
    fuzzyPI.output.mf(i).params = A(i);
    fuzzyPI.rule(i).antecedent = rule_idx1(i);
    fuzzyPI.rule(i).consequent = i;
    fuzzyPI.rule(i).weight = 1;
    fuzzyPI.rule(i).connection = 1;
end

% Sada je moguce simulirati Simulink model s neizrazitim regulatorom i
% analizirati odzive. Neizraziti regulator bi trebao kvalitativno oponasati
% djelovanje PI regulatora.